
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { Landmark, Send, ArrowRightLeft, Headset, Bell, ChevronRight, ChevronLeft } from 'lucide-react';
import type { CryptoCoin, SystemSettings } from '../types.ts';
import { useAuth } from '../contexts/AuthContext.tsx';

// Mock Forex Data
const forexData: CryptoCoin[] = [
    { id: 'eur-usd', symbol: 'EUR', name: 'EUR/USD', image: '', current_price: 1.085, price_change_percentage_24h: 0.25, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'gbp-usd', symbol: 'GBP', name: 'GBP/USD', image: '', current_price: 1.275, price_change_percentage_24h: -0.10, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'usd-jpy', symbol: 'JPY', name: 'USD/JPY', image: '', current_price: 157.2, price_change_percentage_24h: 0.50, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'usd-cad', symbol: 'CAD', name: 'USD/CAD', image: '', current_price: 1.373, price_change_percentage_24h: 0.05, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'aud-usd', symbol: 'AUD', name: 'AUD/USD', image: '', current_price: 0.665, price_change_percentage_24h: -0.30, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
];

const iconComponents: { [key: string]: React.ElementType } = {
    Landmark, Send, ArrowRightLeft, Headset
};

const carouselSlides = [
  {
    image: "https://www.shutterstock.com/image-photo/stock-market-forex-trading-graph-600nw-2333511041.jpg",
    alt: "Stock market forex trading graph"
  },
  {
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeYvfKmui4Z6pHMldkbvlry5szsm5aL72xm8p-d6Rxa9MmBOZ0lo2Bs2utfCRZY6dC5DM&usqp=CAU",
    alt: "Abstract digital chart and graph"
  },
  {
    image: "https://fireforex.in/wp-content/uploads/2023/06/money-exchange.jpg",
    alt: "Hand holding different currency notes for exchange"
  },
];


const HomeScreen = () => {
    const navigate = useNavigate();
    const { user, getSystemSettings } = useAuth();
    const [activeTab, setActiveTab] = React.useState('Flash');
    const [marketData, setMarketData] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [systemSettings, setSystemSettings] = React.useState<SystemSettings | null>(null);
    const [currentSlide, setCurrentSlide] = React.useState(0);

    const nextSlide = React.useCallback(() => {
        setCurrentSlide(prev => (prev === carouselSlides.length - 1 ? 0 : prev + 1));
    }, []);

    const prevSlide = React.useCallback(() => {
        setCurrentSlide(prev => (prev === 0 ? carouselSlides.length - 1 : prev - 1));
    }, []);

    React.useEffect(() => {
        const slideInterval = setInterval(() => {
            nextSlide();
        }, 5000);
        return () => clearInterval(slideInterval);
    }, [nextSlide]);

     React.useEffect(() => {
        getSystemSettings().then(setSystemSettings);
    }, [getSystemSettings]);
    
    React.useEffect(() => {
        const fetchCoinData = async () => {
            setLoading(true);
            try {
                const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
                if (!response.ok) throw new Error('Failed to fetch data');
                const data: CryptoCoin[] = await response.json();
                setMarketData(data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchCoinData();
        const intervalId = setInterval(fetchCoinData, 30000);

        return () => clearInterval(intervalId);
    }, []);
    
    const handleActionClick = (path: string, state?: any) => {
        if (path === '#') {
            alert('This feature is not yet available.');
            return;
        }
        if (path.startsWith('http')) {
            window.open(path, '_blank', 'noopener,noreferrer');
        } else {
            navigate(path, { state });
        }
    };
    
    const MarketRow = ({ coin, isForex = false }: { coin: CryptoCoin; isForex?: boolean }) => {
        const isPositive = (coin.price_change_percentage_24h || 0) >= 0;
        const changeColor = isPositive ? 'text-green-500' : 'text-red-500';
        const changeSign = isPositive ? '+' : '';
        const pairSymbol = isForex ? coin.name.replace('/', '-') : `${coin.symbol.toUpperCase()}-USDT`;

        return (
            <div 
                className="grid grid-cols-3 items-center py-3 px-2 rounded-md hover:bg-slate-900 cursor-pointer transition-colors"
                onClick={() => navigate(`/trading/${pairSymbol}`)}
            >
                <div className="text-left">
                    <p className="font-bold">{isForex ? coin.name : `${coin.symbol.toUpperCase()}/USDT`}</p>
                </div>
                <p className="text-center font-semibold">{coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</p>
                <p className={`text-right font-semibold ${changeColor}`}>{changeSign}{(coin.price_change_percentage_24h || 0).toFixed(2)}%</p>
            </div>
        );
    };
    
    const actionMenuItems = systemSettings?.homepageActionItems
        .filter(item => item.enabled)
        .sort((a,b) => a.order - b.order) || [];

    return (
        <div className="min-h-screen pb-24 font-sans">
             {/* Header */}
            <header className="flex items-center justify-between p-4">
                 <div className="flex items-center space-x-3">
                    <img 
                        src={user?.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${user?.name}`}
                        alt="User"
                        className="w-10 h-10 rounded-full border-2 border-slate-800 object-cover"
                    />
                    <div>
                        <p className="text-sm text-slate-400">Welcome back,</p>
                        <p className="font-bold text-lg">{user?.name}</p>
                    </div>
                </div>
                <button onClick={() => navigate('/profile', {state: {view: 'notifications'}})} className="relative p-2 rounded-full hover:bg-slate-900 transition-colors">
                    <Bell size={24} />
                    {(user?.notifications?.filter(n => !n.read).length || 0) > 0 && 
                        <span className="absolute top-1 right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-black"></span>
                    }
                </button>
            </header>

            <main className="px-4 space-y-6">
                 
                {/* Image Carousel & Actions */}
                <div className="relative w-full h-56 md:h-64 rounded-2xl overflow-hidden shadow-lg group">
                    {carouselSlides.map((slide, index) => (
                        <div
                        key={index}
                        className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
                        >
                        <img src={slide.image} alt={slide.alt} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/50"></div>
                        </div>
                    ))}

                    <button
                        onClick={prevSlide}
                        className="absolute top-1/2 left-2 -translate-y-1/2 bg-black/30 text-white p-2 rounded-full transition-opacity focus:outline-none z-10"
                    >
                        <ChevronLeft size={24} />
                    </button>
                    <button
                        onClick={nextSlide}
                        className="absolute top-1/2 right-2 -translate-y-1/2 bg-black/30 text-white p-2 rounded-full transition-opacity focus:outline-none z-10"
                    >
                        <ChevronRight size={24} />
                    </button>

                    <div className="absolute top-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
                        {carouselSlides.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => setCurrentSlide(index)}
                            className={`w-2 h-2 rounded-full transition-all duration-300 ${index === currentSlide ? 'bg-white w-4' : 'bg-white/50 hover:bg-white'}`}
                        ></button>
                        ))}
                    </div>

                    {/* Quick Action Menu - Overlaid */}
                    <div className="absolute bottom-4 left-4 right-4 grid grid-cols-4 gap-2 text-center z-10">
                        {actionMenuItems.map((item) => {
                           const Icon = iconComponents[item.icon];
                           if (!Icon) return null;
                           return (
                                <button key={item.id} onClick={() => handleActionClick(item.path, item.state)} className="flex flex-col items-center space-y-2 text-white hover:opacity-80 transition-opacity">
                                    <div className="w-12 h-12 bg-slate-900/70 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/10">
                                        <Icon size={24} className="text-purple-400" />
                                    </div>
                                    <span className="text-xs font-medium shadow-black [text-shadow:_0_1px_2px_var(--tw-shadow-color)]">{item.label}</span>
                                </button>
                            )
                        })}
                    </div>
                </div>

                {/* Market Data */}
                <div>
                    <div className="flex space-x-6 border-b border-slate-800 mb-2">
                        <button onClick={() => setActiveTab('Flash')} className={`py-2 font-semibold transition-colors ${activeTab === 'Flash' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Flash
                        </button>
                         <button onClick={() => setActiveTab('Forex')} className={`py-2 font-semibold transition-colors ${activeTab === 'Forex' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Forex
                        </button>
                    </div>

                    <div>
                        <div className="grid grid-cols-3 text-sm text-gray-500 mb-2 px-2">
                            <p className="text-left">Name</p>
                            <p className="text-center">Last Price</p>
                            <p className="text-right">24H Change</p>
                        </div>
                        <div className="space-y-1">
                            {loading && activeTab === 'Flash' && <p className="text-center text-gray-400 py-4">Loading...</p>}
                            {!loading && activeTab === 'Flash' && marketData.map(coin => <MarketRow key={coin.id} coin={coin} />)}
                            {activeTab === 'Forex' && forexData.map(coin => <MarketRow key={coin.id} coin={coin} isForex={true} />)}
                        </div>
                         <div className="text-center mt-4">
                           <button onClick={() => navigate('/markets')} className="text-gray-500 hover:text-white transition-colors text-sm font-medium">
                               View All Markets
                           </button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomeScreen;