
import * as React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronRight, Bell, Lock, Sun, Moon, CreditCard, Download, Repeat, ArrowLeft, HelpCircle, Mail, Users, LogOut, AlertCircle, Loader, Camera, ShieldCheck, CheckCircle2, Clock, XCircle, KeyRound, QrCode, ClipboardCopy } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { User, KYCStatus, Notification, ReferralInfo } from '../types.ts';
import { useTheme } from '../contexts/ThemeContext.tsx';

// --- Reusable Components & Helpers ---

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});

const FormInput = ({ id, label, type = 'text', value, onChange, placeholder = '', required = true, disabled = false, name = id }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300">{label}</label>
        <input
            type={type}
            id={id}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            required={required}
            disabled={disabled}
            className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-purple-500 focus:border-purple-500 disabled:bg-slate-200 dark:disabled:bg-slate-700"
        />
    </div>
);

const CountrySelect = ({ id, value, onChange }) => {
    const countries = [ "Brazil", "United States", "Canada", "United Kingdom", "Germany", "France", "Japan", "Australia", "India", "Mexico", "Argentina", "South Korea" ];
    return (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-gray-700 dark:text-gray-300">Country</label>
            <select
                id={id}
                name={id}
                value={value}
                onChange={onChange}
                required
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-700 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
            >
                <option value="">Select a country</option>
                {countries.map(country => <option key={country} value={country}>{country}</option>)}
            </select>
        </div>
    );
};

const KycStatusBadge = ({ status, onClick }: { status: KYCStatus; onClick?: () => void }) => {
    const statusInfo = {
        verified: { Icon: CheckCircle2, text: 'Verified', className: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' },
        pending: { Icon: Clock, text: 'Pending Review', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300' },
        unverified: { Icon: AlertCircle, text: 'Unverified', className: 'bg-gray-200 text-gray-800 dark:bg-slate-700 dark:text-slate-300' },
        rejected: { Icon: XCircle, text: 'Rejected', className: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300' },
    }[status];

    const Tag = onClick ? 'button' : 'span';

    return (
        <Tag
            onClick={onClick}
            className={`mt-2 inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide ${statusInfo.className} ${onClick ? 'hover:opacity-80 transition-opacity' : ''}`}
        >
            <statusInfo.Icon size={14} className="mr-1.5" />
            {statusInfo.text}
        </Tag>
    );
};

const MenuItem = ({ icon, label, onClick, badge }: { icon: React.ReactNode; label: string; onClick: () => void; badge?: number; }) => (
    <button onClick={onClick} className="w-full flex items-center justify-between p-4 bg-white dark:bg-slate-900 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors shadow-sm dark:shadow-none">
        <div className="flex items-center space-x-4">
            {icon}
            <span className="font-medium text-slate-900 dark:text-white">{label}</span>
        </div>
        <div className="flex items-center space-x-3">
            {badge > 0 && (
                <span className="bg-purple-600 text-white text-xs font-bold w-6 h-6 flex items-center justify-center rounded-full">{badge}</span>
            )}
            <ChevronRight size={20} className="text-gray-400 dark:text-gray-500" />
        </div>
    </button>
);


const ViewContainer = ({ title, onBack, children }: { title: string; onBack: () => void; children: React.ReactNode }) => (
    <div className="animate-fade-in">
        <header className="flex items-center mb-6">
            <button onClick={onBack} className="p-2 mr-2 rounded-full hover:bg-gray-200 dark:hover:bg-slate-800">
                <ArrowLeft size={24} />
            </button>
            <h2 className="text-2xl font-bold">{title}</h2>
        </header>
        {children}
    </div>
);

// --- New Wallet Components ---

const ChevronDownIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
        className="h-4 w-4 text-purple-500 dark:text-purple-400">
        <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
);

const Wallets = ({ user, setView }: { user: User; setView: (view: string) => void; }) => {
    const balance = user.portfolio.balance;
    const balanceInt = Math.floor(balance);
    const balanceDec = (balance - balanceInt).toFixed(2).substring(2);

    return (
        <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-gray-200 dark:border-slate-800 shadow-lg dark:shadow-2xl text-slate-900 dark:text-slate-100 font-sans">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-4">Wallets</h2>
            
            <div className="mb-6">
                <div className="flex justify-between items-baseline">
                    <div>
                        <span className="text-5xl font-bold tracking-tighter">{balanceInt.toLocaleString()}</span>
                        <span className="text-3xl font-semibold text-gray-500 dark:text-slate-300">.{balanceDec}</span>
                    </div>
                    <button className="flex items-center space-x-2 px-3 py-1 rounded-md bg-gray-200 dark:bg-slate-800 hover:bg-gray-300 dark:hover:bg-slate-700 transition-colors">
                        <span className="font-semibold text-purple-500 dark:text-purple-400">USD</span>
                        <ChevronDownIcon />
                    </button>
                </div>
                <p className="text-sm text-gray-500 dark:text-slate-400 mt-1">Total Wallets value</p>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
                <button 
                    onClick={() => setView('deposit')}
                    className="w-full bg-purple-600 text-white font-bold py-3 rounded-lg hover:bg-purple-700 active:bg-purple-800 transition-all duration-200 shadow-md transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-400 focus:ring-opacity-50">
                    Deposit
                </button>
                <button 
                    onClick={() => alert("Transfer feature is not available yet.")}
                    className="w-full bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold py-3 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 active:bg-slate-400 dark:active:bg-slate-800 transition-all duration-200 shadow-md transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-slate-400 dark:focus:ring-slate-500 focus:ring-opacity-50">
                    Transfer
                </button>
                <button 
                    onClick={() => setView('withdraw')}
                    className="w-full bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold py-3 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 active:bg-slate-400 dark:active:bg-slate-800 transition-all duration-200 shadow-md transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-slate-400 dark:focus:ring-slate-500 focus:ring-opacity-50">
                    Withdraw
                </button>
            </div>
        </div>
    );
};

// --- Sub-Views ---

const ProfileView = ({ user, setView, onLogout, isAdmin }: { user: User, setView: (view: string) => void, onLogout: () => void, isAdmin: boolean }) => {
    const { theme, toggleTheme } = useTheme();
    const navigate = useNavigate();
    const { updateUserPhoto, isLoading } = useAuth();
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const unreadCount = user.notifications.filter(n => !n.read).length;

    const handlePhotoClick = () => fileInputRef.current?.click();

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            try {
                await updateUserPhoto(file);
            } catch (error) {
                console.error("Failed to upload photo", error);
            }
        }
    };

    return (
        <div className="space-y-6 animate-fade-in">
             <header className="flex items-center justify-between py-2">
                 <div className="flex items-center space-x-3">
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" style={{ display: 'none' }} disabled={isLoading} />
                    <div className="relative group flex-shrink-0 cursor-pointer" onClick={handlePhotoClick}>
                        <img 
                            src={user?.photoURL || `https://api.dicebear.com/8.x/initials/svg?seed=${user?.name}`}
                            alt="User"
                            className="w-16 h-16 rounded-full border-2 border-slate-700 object-cover"
                        />
                         <div className="absolute inset-0 bg-black/60 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                            {isLoading ? <Loader size={20} className="animate-spin" /> : <Camera size={20} />}
                        </div>
                    </div>
                    <div>
                        <p className="font-bold text-xl">{user?.name}</p>
                         <KycStatusBadge status={user.kycStatus} onClick={() => setView('kyc')} />
                    </div>
                </div>
                 <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-slate-800 transition-colors">
                    {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                </button>
            </header>
            
            <Wallets user={user} setView={setView} />

            {isAdmin && (
                <MenuItem icon={<ShieldCheck size={20} className="text-purple-500"/>} label="Admin Panel" onClick={() => navigate('/admin')} />
            )}

            {/* Menu Groups */}
            <div className="space-y-6">
                 <div>
                    <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 px-4 mb-2">MY SERVICES</h3>
                    <div className="space-y-2">
                        <MenuItem icon={<ShieldCheck size={20} className="text-green-500"/>} label="Identity Verification" onClick={() => setView('kyc')} />
                        <MenuItem icon={<Repeat size={20} className="text-blue-500"/>} label="Transaction History" onClick={() => navigate('/history')} />
                    </div>
                 </div>
                 
                 <div>
                    <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 px-4 mb-2">SETTINGS</h3>
                    <div className="space-y-2">
                        <MenuItem icon={<Lock size={20} className="text-yellow-500"/>} label="Security Settings" onClick={() => setView('security')} />
                        <MenuItem icon={<Bell size={20} className="text-red-500"/>} label="Notifications" onClick={() => setView('notifications')} badge={unreadCount} />
                        <MenuItem icon={<Users size={20} className="text-teal-500"/>} label="Referrals" onClick={() => setView('referrals')} />
                         <MenuItem icon={<HelpCircle size={20} className="text-indigo-500"/>} label="Help & Support" onClick={() => alert("Help & Support coming soon!")} />
                    </div>
                 </div>
            </div>
            
            <div className="pt-4">
                 <MenuItem icon={<LogOut size={20} className="text-red-500"/>} label="Log Out" onClick={onLogout} />
            </div>
        </div>
    );
};

const KycView = ({ user, onBack }) => {
    const { submitKyc, isLoading } = useAuth();
    const [formData, setFormData] = React.useState({
        fullName: user.fullName || user.name || '',
        dateOfBirth: user.dateOfBirth || '',
        country: user.country || '',
        address: user.address || '',
    });
    const [idFront, setIdFront] = React.useState<File | null>(null);
    const [idBack, setIdBack] = React.useState<File | null>(null);
    const [error, setError] = React.useState('');

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<File | null>>) => {
        const file = e.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            setter(file);
        } else {
            e.target.value = '';
            setter(null);
            alert("Please select a valid image file.");
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!idFront || !idBack) {
            setError('Please upload images of the front and back of your ID.');
            return;
        }
        try {
            const idFrontBase64 = await toBase64(idFront);
            const idBackBase64 = await toBase64(idBack);
            await submitKyc({ ...formData, idFrontBase64, idBackBase64 });
            onBack(); // Go back after successful submission
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred.');
        }
    };
    
    if (user.kycStatus === 'verified') {
        return (
            <ViewContainer title="Identity Verification" onBack={onBack}>
                <div className="text-center p-8 bg-white dark:bg-slate-900 rounded-lg">
                    <CheckCircle2 size={64} className="mx-auto text-green-500" />
                    <h3 className="mt-4 text-xl font-bold">You're Verified!</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">Your identity has been successfully verified. You have full access to all features.</p>
                </div>
            </ViewContainer>
        );
    }
    
    if (user.kycStatus === 'pending') {
        return (
             <ViewContainer title="Identity Verification" onBack={onBack}>
                <div className="text-center p-8 bg-white dark:bg-slate-900 rounded-lg">
                    <Clock size={64} className="mx-auto text-yellow-500" />
                    <h3 className="mt-4 text-xl font-bold">Verification Pending</h3>
                    <p className="mt-2 text-gray-500 dark:text-gray-400">Your documents are under review. This usually takes 1-3 business days. We'll notify you once it's complete.</p>
                </div>
            </ViewContainer>
        );
    }

    return (
        <ViewContainer title="Identity Verification" onBack={onBack}>
            <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-white dark:bg-slate-900 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-300">Please provide your legal information as it appears on your government-issued ID.</p>
                
                {user.kycStatus === 'rejected' && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300 rounded-lg">
                        Your previous submission was rejected. Please review your information and try again.
                    </div>
                )}

                <FormInput id="fullName" label="Full Legal Name" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} placeholder="Your full legal name" />
                <FormInput id="dateOfBirth" label="Date of Birth" type="date" value={formData.dateOfBirth} onChange={e => setFormData({...formData, dateOfBirth: e.target.value})} />
                <CountrySelect id="country" value={formData.country} onChange={e => setFormData({...formData, country: e.target.value})} />
                <FormInput id="address" label="Residential Address" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} placeholder="123 Fortress Way" />

                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ID Front</label>
                    <input type="file" accept="image/*" onChange={e => handleFileChange(e, setIdFront)} className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-100 file:text-purple-700 hover:file:bg-purple-200 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">ID Back</label>
                    <input type="file" accept="image/*" onChange={e => handleFileChange(e, setIdBack)} className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-100 file:text-purple-700 hover:file:bg-purple-200 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" />
                </div>
                
                {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400 disabled:cursor-not-allowed">
                    {isLoading ? <Loader className="animate-spin" /> : 'Submit for Verification'}
                </button>
            </form>
        </ViewContainer>
    );
};

const DepositView = ({ onBack }) => {
    const { deposit, isLoading, getSystemSettings } = useAuth();
    const [network, setNetwork] = React.useState<'TRC20' | 'ERC20' | 'BTC'>('TRC20');
    const [amount, setAmount] = React.useState('');
    const [txProof, setTxProof] = React.useState<File | null>(null);
    const [txProofPreview, setTxProofPreview] = React.useState<string | null>(null);
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');
    const [addresses, setAddresses] = React.useState({
        TRC20: '', ERC20: '', BTC: ''
    });

    React.useEffect(() => {
        getSystemSettings().then(settings => {
            setAddresses({
                TRC20: settings.depositAddressTrc20,
                ERC20: settings.depositAddressErc20,
                BTC: settings.depositAddressBtc,
            });
        });
    }, [getSystemSettings]);

    const networks = {
        'TRC20': { name: 'TRC20 (USDT)', address: addresses.TRC20, asset: 'USDT' },
        'ERC20': { name: 'ERC20 (USDT)', address: addresses.ERC20, asset: 'USDT' },
        'BTC': { name: 'Bitcoin', address: addresses.BTC, asset: 'BTC' },
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file && file.type.startsWith('image/')) {
            setTxProof(file);
            setTxProofPreview(URL.createObjectURL(file));
        } else {
            if(file) alert("Please select a valid image file.");
            e.target.value = '';
            setTxProof(null);
            setTxProofPreview(null);
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (!amount || parseFloat(amount) <= 0) {
            setError('Please enter a valid amount.');
            return;
        }
        if (!txProof) {
            setError('Please upload a transaction proof screenshot.');
            return;
        }

        try {
            const proofBase64 = await toBase64(txProof);
            await deposit({
                amount: parseFloat(amount),
                network,
                asset: networks[network].asset,
                transactionProof: proofBase64
            });
            setSuccess('Deposit submitted successfully! It will be reviewed shortly.');
            setAmount('');
            setTxProof(null);
            setTxProofPreview(null);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Deposit submission failed.');
        }
    };
    
    return (
        <ViewContainer title="Deposit Funds" onBack={onBack}>
            <div className="space-y-6 p-4 bg-white dark:bg-slate-900 rounded-lg">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Network</label>
                    <div className="mt-2 grid grid-cols-3 gap-2 rounded-lg bg-gray-200 dark:bg-slate-800 p-1">
                        {Object.keys(networks).map((net) => (
                            <button
                                key={net}
                                onClick={() => setNetwork(net as 'TRC20' | 'ERC20' | 'BTC')}
                                className={`px-3 py-2 text-sm font-semibold rounded-md transition-colors ${network === net ? 'bg-white text-purple-600 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-gray-600 hover:bg-white/50 dark:text-gray-400 dark:hover:bg-slate-700/50'}`}
                            >
                                {networks[net].name}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="p-4 border border-dashed border-gray-300 dark:border-slate-700 rounded-lg">
                    <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Send only {networks[network].asset} to this address.</p>
                    <p className="text-sm font-mono break-all text-slate-800 dark:text-slate-200">{networks[network].address || 'Loading...'}</p>
                    <button 
                      onClick={() => navigator.clipboard.writeText(networks[network].address)}
                      className="mt-2 text-xs font-semibold text-purple-600 dark:text-purple-400 hover:underline"
                    >
                      Copy Address
                    </button>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                     <FormInput
                        id="amount"
                        label={`Amount (${networks[network].asset})`}
                        type="number"
                        value={amount}
                        onChange={e => setAmount(e.target.value)}
                        placeholder="0.00"
                    />
                     <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Transaction Proof</label>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Upload a screenshot of your transaction confirmation.</p>
                         <input 
                            type="file" 
                            accept="image/*" 
                            onChange={handleFileChange} 
                            className="mt-1 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 dark:file:bg-slate-700 dark:file:text-purple-300 dark:hover:file:bg-slate-600 w-full text-gray-500" 
                        />
                         {txProofPreview && (
                            <div className="mt-4">
                               <img src={txProofPreview} alt="Transaction proof preview" className="rounded-lg max-h-48 w-auto mx-auto border dark:border-slate-700"/>
                            </div>
                         )}
                    </div>

                    {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                    {success && <p className="text-sm text-green-500 dark:text-green-400">{success}</p>}

                    <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400 disabled:cursor-not-allowed">
                        {isLoading ? <Loader className="animate-spin" /> : 'Submit Deposit'}
                    </button>
                </form>

            </div>
        </ViewContainer>
    );
};

const WithdrawView = ({ onBack }) => {
    const { withdraw, user, isLoading } = useAuth();
    const [loginPassword, setLoginPassword] = React.useState('');
    const [amount, setAmount] = React.useState('');
    const [address, setAddress] = React.useState('');
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        try {
            await withdraw(loginPassword, { amount: parseFloat(amount), address, asset: 'USDT' });
            setSuccess(`Withdrawal for ${amount} USDT submitted for review.`);
            setLoginPassword(''); setAmount(''); setAddress('');
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Withdrawal failed.');
        }
    };
    
    if (user.kycStatus !== 'verified') {
       return (
            <ViewContainer title="Withdraw Funds" onBack={onBack}>
                <div className="p-4 bg-yellow-100 dark:bg-yellow-900/50 rounded-lg text-yellow-800 dark:text-yellow-200">
                    <AlertCircle className="inline mr-2" />
                    Please verify your identity before making a withdrawal.
                </div>
            </ViewContainer>
        );
    }
    
    return (
        <ViewContainer title="Withdraw Funds" onBack={onBack}>
            <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-white dark:bg-slate-900 rounded-lg">
                <FormInput id="amount" label="Amount (USDT)" type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" />
                <FormInput id="address" label="Withdrawal Address (USDT TRC20)" value={address} onChange={e => setAddress(e.target.value)} placeholder="T..." />
                <FormInput id="loginPassword" label="Login Password" type="password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} placeholder="••••••••" />
                
                {error && <p className="text-sm text-red-500 dark:text-red-400">{error}</p>}
                {success && <p className="text-sm text-green-500 dark:text-green-400">{success}</p>}
                
                 <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400">
                    {isLoading ? <Loader className="animate-spin" /> : 'Submit Withdrawal'}
                </button>
            </form>
        </ViewContainer>
    );
};

const NotificationsView = ({ user, onBack }: { user: User; onBack: () => void; }) => {
    const { markAllNotificationsAsRead, markNotificationAsRead, isLoading } = useAuth();

    const handleMarkAllRead = async () => {
        if (user.notifications.some(n => !n.read)) {
            await markAllNotificationsAsRead();
        }
    };
    
    const handleMarkOneRead = (notificationId: string) => {
        const notification = user.notifications.find(n => n.id === notificationId);
        if (notification && !notification.read) {
             markNotificationAsRead(notificationId);
        }
    }

    const sortedNotifications = [...user.notifications].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const notificationIcons = {
        transaction: <Repeat size={24} className="text-purple-500" />,
        security: <ShieldCheck size={24} className="text-yellow-500" />,
        system: <Bell size={24} className="text-purple-500" />,
    };

    return (
        <ViewContainer title="Notifications" onBack={onBack}>
            <div className="mb-4 flex justify-end">
                <button 
                    onClick={handleMarkAllRead}
                    disabled={isLoading || !user.notifications.some(n => !n.read)}
                    className="flex items-center px-3 py-1.5 bg-purple-100 dark:bg-slate-700 text-purple-700 dark:text-purple-300 rounded-md text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <Mail size={16} className="mr-2"/>
                    Mark all as read
                </button>
            </div>
            <div className="space-y-3">
                {sortedNotifications.length > 0 ? (
                    sortedNotifications.map(notification => (
                        <div 
                            key={notification.id} 
                            onClick={() => handleMarkOneRead(notification.id)}
                            className={`relative p-4 pl-8 bg-white dark:bg-slate-900 rounded-lg flex items-start space-x-4 border-l-4 transition-colors ${!notification.read ? 'border-purple-500 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-800' : 'border-transparent'}`}
                        >
                            {!notification.read && <div className="absolute left-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>}
                            <div className="flex-shrink-0 pt-1">
                                {notificationIcons[notification.type]}
                            </div>
                            <div className="flex-grow">
                                <p className={`font-bold ${!notification.read ? 'text-slate-900 dark:text-white' : 'text-gray-600 dark:text-gray-400'}`}>{notification.title}</p>
                                <p className={`text-sm mt-1 ${!notification.read ? 'text-gray-600 dark:text-gray-300' : 'text-gray-500 dark:text-gray-400'}`}>{notification.message}</p>
                                <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">{new Date(notification.date).toLocaleString()}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="text-center p-8 bg-white dark:bg-slate-900 rounded-lg">
                        <Bell size={48} className="mx-auto text-gray-400" />
                        <h3 className="mt-4 text-xl font-bold">You're all caught up!</h3>
                        <p className="mt-2 text-gray-500 dark:text-gray-400">You have no new notifications.</p>
                    </div>
                )}
            </div>
        </ViewContainer>
    );
};

const SecurityView = ({ user, onBack }) => {
    const { changePassword, isLoading } = useAuth();
    const [error, setError] = React.useState('');
    const [success, setSuccess] = React.useState('');

    const [passwordData, setPasswordData] = React.useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
    
    const handlePasswordDataChange = (e: React.ChangeEvent<HTMLInputElement>) => setPasswordData({ ...passwordData, [e.target.name]: e.target.value });
    
    const handlePasswordChange = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        const { currentPassword, newPassword, confirmPassword } = passwordData;
        if (newPassword !== confirmPassword) {
            setError('New passwords do not match.'); return;
        }
        try {
            await changePassword(currentPassword, newPassword);
            setSuccess('Login password changed successfully.');
            setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred.');
        }
    };
    
    return (
        <ViewContainer title="Security Settings" onBack={onBack}>
             {error && <p className="mb-4 text-sm text-center text-red-500 dark:text-red-400 p-3 bg-red-100 dark:bg-red-900/50 rounded-lg">{error}</p>}
            {success && <p className="mb-4 text-sm text-center text-green-500 dark:text-green-400 p-3 bg-green-100 dark:bg-green-900/50 rounded-lg">{success}</p>}
            <form onSubmit={handlePasswordChange} className="space-y-4 p-4 bg-white dark:bg-slate-900 rounded-lg">
                <h3 className="text-lg font-bold">Change Login Password</h3>
                <FormInput id="currentPassword" name="currentPassword" label="Current Login Password" type="password" value={passwordData.currentPassword} onChange={handlePasswordDataChange} />
                <FormInput id="newPassword" name="newPassword" label="New Login Password" type="password" value={passwordData.newPassword} onChange={handlePasswordDataChange} />
                <FormInput id="confirmPassword" name="confirmPassword" label="Confirm New Password" type="password" value={passwordData.confirmPassword} onChange={handlePasswordDataChange} />
                <button type="submit" disabled={isLoading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400">
                    {isLoading ? <Loader className="animate-spin" /> : 'Change Password'}
                </button>
            </form>
        </ViewContainer>
    );
};

const ReferralsView = ({ user, onBack }: { user: User; onBack: () => void; }) => {
    const [copied, setCopied] = React.useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(user.referralCode);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <ViewContainer title="Referrals" onBack={onBack}>
            <div className="p-4 bg-white dark:bg-slate-900 rounded-lg space-y-6">
                <div className="text-center p-6 bg-purple-50 dark:bg-slate-800/50 rounded-lg">
                    <h3 className="text-lg font-bold">Your Referral Code</h3>
                    <div className="my-4 flex items-center justify-center space-x-2 bg-gray-100 dark:bg-slate-900 p-3 rounded-lg">
                        <span className="text-2xl font-mono font-bold text-purple-600 dark:text-purple-400">{user.referralCode}</span>
                        <button onClick={handleCopy} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors">
                            {copied ? <CheckCircle2 size={20} className="text-green-500" /> : <ClipboardCopy size={20} />}
                        </button>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Share this code with friends. You'll earn a reward when they make their first deposit!</p>
                </div>

                <div>
                    <h3 className="text-lg font-bold mb-3">Your Referrals ({user.referredUsers.length})</h3>
                    <div className="space-y-3">
                        {user.referredUsers.length > 0 ? (
                            user.referredUsers.map(ref => (
                                <div key={ref.uid} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-slate-800 rounded-md">
                                    <div>
                                        <p className="font-semibold">{ref.name}</p>
                                        <p className="text-xs text-gray-500 dark:text-gray-400">Referred on: {new Date(ref.date).toLocaleDateString()}</p>
                                    </div>
                                    <div className="text-right">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${ref.status === 'deposited' ? 'bg-green-100 text-green-800 dark:bg-green-800/50 dark:text-green-300' : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800/50 dark:text-yellow-300'}`}>
                                            {ref.status}
                                        </span>
                                        {ref.status === 'deposited' && <p className="text-sm font-bold text-green-500 mt-1">+${ref.reward}</p>}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <p className="text-center text-gray-500 dark:text-gray-400 py-4">You haven't referred anyone yet.</p>
                        )}
                    </div>
                </div>
            </div>
        </ViewContainer>
    );
};


const LoginView = ({ onLogin, onSwitchToSignup, isLoading }) => {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        try {
            await onLogin(email, password, { userAgent: navigator.userAgent });
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Login failed.');
        }
    };
    
    return (
        <div className="min-h-screen flex flex-col justify-center items-center p-4">
             <div className="w-full max-w-md space-y-8">
                 <div>
                    <h2 className="mt-6 text-center text-3xl font-extrabold text-slate-900 dark:text-white">
                       Sign in to your account
                    </h2>
                 </div>
                <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
                    <div className="rounded-md shadow-sm">
                        <FormInput id="email" label="Email address" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email address" />
                        <div className="pt-4">
                            <FormInput id="password" label="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" />
                        </div>
                    </div>
                    {error && <p className="text-sm text-center text-red-500 dark:text-red-400">{error}</p>}
                    <div>
                        <button type="submit" disabled={isLoading} className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400">
                             {isLoading ? <Loader className="animate-spin" /> : 'Sign in'}
                        </button>
                    </div>
                </form>
                 <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
                    Or{' '}
                    <button onClick={onSwitchToSignup} className="font-medium text-purple-600 hover:text-purple-500">
                        create a new account
                    </button>
                </p>
             </div>
        </div>
    );
};

const SignupView = ({ onSignup, onSwitchToLogin, isLoading }) => {
    const [formData, setFormData] = React.useState({
        name: '', email: '', password: '', confirmPassword: '', referralCode: '',
        dateOfBirth: '', country: '', address: ''
    });
    const [error, setError] = React.useState('');
    
    const handleChange = (e) => setFormData({...formData, [e.target.name]: e.target.value});

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (formData.password !== formData.confirmPassword) {
            setError("Passwords do not match.");
            return;
        }
        if (!formData.referralCode) {
            setError("A referral code is required.");
            return;
        }
        try {
            await onSignup(formData.name, formData.email, formData.password, {dateOfBirth: formData.dateOfBirth, country: formData.country, address: formData.address }, formData.referralCode);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Signup failed.');
        }
    };
    
    return (
        <div className="min-h-screen flex flex-col justify-center items-center p-4">
             <div className="w-full max-w-md space-y-8">
                 <div>
                    <h2 className="mt-6 text-center text-3xl font-extrabold text-slate-900 dark:text-white">
                       Create a new account
                    </h2>
                 </div>
                <form className="mt-8 space-y-4" onSubmit={handleSubmit}>
                    <FormInput id="name" label="Name" value={formData.name} onChange={handleChange} />
                    <FormInput id="email" label="Email" type="email" value={formData.email} onChange={handleChange} />
                    <FormInput id="password" label="Password" type="password" value={formData.password} onChange={handleChange} />
                    <FormInput id="confirmPassword" label="Confirm Password" type="password" value={formData.confirmPassword} onChange={handleChange} />
                    <FormInput id="referralCode" label="Referral Code" placeholder="Referral code is required" value={formData.referralCode} onChange={handleChange} />
                    <FormInput id="dateOfBirth" label="Date of Birth" type="date" value={formData.dateOfBirth} onChange={handleChange} />
                    <CountrySelect id="country" value={formData.country} onChange={handleChange} />
                    <FormInput id="address" label="Address" value={formData.address} onChange={handleChange} />

                    {error && <p className="text-sm text-center text-red-500 dark:text-red-400">{error}</p>}
                    <div>
                        <button type="submit" disabled={isLoading} className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:bg-purple-400">
                             {isLoading ? <Loader className="animate-spin" /> : 'Sign up'}
                        </button>
                    </div>
                </form>
                 <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
                    Already have an account?{' '}
                    <button onClick={onSwitchToLogin} className="font-medium text-purple-600 hover:text-purple-500">
                        Sign in
                    </button>
                </p>
             </div>
        </div>
    );
};


const ProfileScreen = () => {
  const { user, login, signup, logout, isLoading, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [authView, setAuthView] = React.useState('login'); // 'login' or 'signup'
  
  // The state from navigate('/profile', { state: { view: 'deposit' } })
  const requestedView = location.state?.view;
  const [view, setView] = React.useState('main'); // 'main', 'kyc', etc.

  // When the component mounts or the state from location changes, update the view
  React.useEffect(() => {
    if (requestedView) {
      setView(requestedView);
      // clear the state after using it
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [requestedView, navigate, location.pathname]);

  if (!user) {
    if (authView === 'login') {
        return <LoginView onLogin={login} onSwitchToSignup={() => setAuthView('signup')} isLoading={isLoading} />;
    }
    return <SignupView onSignup={signup} onSwitchToLogin={() => setAuthView('login')} isLoading={isLoading} />;
  }

  const renderView = () => {
    switch (view) {
      case 'kyc':
        return <KycView user={user} onBack={() => setView('main')} />;
      case 'deposit':
        return <DepositView onBack={() => setView('main')} />;
      case 'withdraw':
        return <WithdrawView onBack={() => setView('main')} />;
      case 'notifications':
        return <NotificationsView user={user} onBack={() => setView('main')} />;
      case 'security':
        return <SecurityView user={user} onBack={() => setView('main')} />;
      case 'referrals':
        return <ReferralsView user={user} onBack={() => setView('main')} />;
      default:
        return <ProfileView user={user} setView={setView} onLogout={logout} isAdmin={!!isAdmin} />;
    }
  };

  return (
    <div className="p-4 max-w-3xl mx-auto pb-24">
      {renderView()}
    </div>
  );
};

export default ProfileScreen;
