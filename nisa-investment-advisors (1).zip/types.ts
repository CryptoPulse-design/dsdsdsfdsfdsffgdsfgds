
export interface CryptoCoin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  high_24h: number | null;
  low_24h: number | null;
  price_change_percentage_24h: number | null;
}

export type SortKey = 'market_cap' | 'current_price' | 'price_change_percentage_24h';

export interface Order {
    price: number;
    amount: number;
    total: number;
}

export interface Trade {
    id: string;
    time: string;
    price: number;
    amount: number;
    type: 'buy' | 'sell';
}

// --- SHARED USER & TRANSACTION TYPES ---

export type KYCStatus = 'unverified' | 'pending' | 'verified' | 'rejected';
export type UserStatus = 'active' | 'suspended';

export interface Notification {
  id: string;
  title: string;
  message: string;
  date: string; // ISO string
  read: boolean;
  type: 'security' | 'transaction' | 'system';
}

export interface Transaction {
  id:string;
  type: 'Deposit' | 'Withdrawal' | 'Trade' | 'Admin Adjustment';
  asset: string;
  amount: number; // For trades, this is the PROFIT/LOSS.
  status: 'Completed' | 'Pending' | 'Failed';
  date: string; // This will be the start time for trades
  network?: 'TRC20' | 'ERC20' | 'BTC';
  transactionProof?: string;
  address?: string;
  
  // Trade specific
  pair?: string;
  direction?: 'Buy' | 'Sell';
  stake?: number;
  commission?: number;
  profit?: number; // Redundant with amount, but explicit.
  entryPrice?: number;
  exitPrice?: number;
  endTime?: string; // For trades
  settlementDuration?: number;
  profitPercentage?: number;
  commissionPercentage?: number;

  // For Admin UI
  userEmail?: string;
  userName?: string;
}

export interface UserPortfolio {
  balance: number;
  pendingBalance: number;
  pl: number;
  plPercentage: number;
  referralRewards: number;
}

export interface LoginRecord {
  date: string; // ISO string
  ipAddress: string;
  device: string; // User agent string
}

export interface ReferralInfo {
  uid: string;
  name: string;
  status: 'registered' | 'deposited';
  reward: number;
  date: string; // ISO string
}

export interface SecondContractTrade {
  id: string;
  pair: string;
  type: 'buy' | 'sell';
  duration: number; // in seconds
  profitRate: number; // e.g., 0.85 for 85%
  commissionRate: number;
  amount: number; // stake
  status: 'active' | 'won' | 'lost' | 'pending_settlement';
  entryPrice: number;
  closePrice?: number;
  closesAt: string; // ISO string
  created_date: string; // ISO string
  userId: string;
  userName?: string; // for admin view
}

export interface User {
  name: string;
  email: string;
  uid: string;
  photoURL?: string;
  password?: string; // This is for mock auth only

  portfolio: UserPortfolio;
  transactions: Transaction[];
  notifications: Notification[];
  
  activeSecondContracts: SecondContractTrade[];
  secondContractHistory: SecondContractTrade[];
  
  kycStatus: KYCStatus;
  status?: UserStatus;
  fullName?: string;
  dateOfBirth?: string;
  country?: string;
  address?: string;
  
  loginHistory: LoginRecord[];

  isAdmin?: boolean;

  referralCode: string;
  referredUsers: ReferralInfo[];
}


// --- ADMIN PANEL TYPES ---

export interface KycRequest {
    user: User;
    kycImages: {
        idFront: string;
        idBack: string;
    };
}

export interface PendingDeposit {
    userEmail: string;
    userName: string;
    userId: string;
    transaction: Transaction;
}

export interface PendingWithdrawal {
    userEmail: string;
    userName: string;
    userId: string;
    transaction: Transaction;
}


// --- API-SPECIFIC TYPES ---
export interface UserDetails {
    dateOfBirth: string;
    country: string;
    address: string;
}

export interface KYCData {
    fullName: string;
    dateOfBirth: string;
    country: string;
    address: string;
    idFrontBase64: string;
    idBackBase64: string;
}

export interface SystemSettings {
    depositAddressTrc20: string;
    depositAddressErc20: string;
    depositAddressBtc: string;
    homepageActionItems: {
      id: string;
      order: number;
      enabled: boolean;
      label: string;
      icon: string;
      path: string;
      state: any;
    }[];
}
