
import * as React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import HomeScreen from './screens/HomeScreen.tsx';
import MarketsScreen from './screens/MarketsScreen.tsx';
import TradingScreen from './screens/TradingScreen.tsx';
import ProfileScreen from './screens/ProfileScreen.tsx';
import BottomNav from './components/BottomNav.tsx';
import ProtectedRoute from './components/ProtectedRoute.tsx';
import { useAuth } from './contexts/AuthContext.tsx';
import { Loader } from 'lucide-react';
import AdminRoute from './components/AdminRoute.tsx';
import AdminScreen from './screens/AdminScreen.tsx';
import HistoryScreen from './screens/HistoryScreen.tsx';

const App = () => {
  const { isLoggedIn, isInitialized } = useAuth();
  const location = useLocation();
  const isAdminPage = location.pathname.startsWith('/admin');

  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-white">
        <Loader className="animate-spin" size={48} />
      </div>
    );
  }

  return (
    <div className="bg-gray-50 dark:bg-slate-950 text-slate-900 dark:text-white min-h-screen font-sans">
      <main className={isLoggedIn && !isAdminPage ? "pb-24" : ""}>
        <Routes>
          <Route path="/profile" element={<ProfileScreen />} />
          <Route path="/" element={<ProtectedRoute><HomeScreen /></ProtectedRoute>} />
          <Route path="/markets" element={<ProtectedRoute><MarketsScreen /></ProtectedRoute>} />
          <Route path="/trading" element={<ProtectedRoute><TradingScreen /></ProtectedRoute>} />
          <Route path="/trading/:pair" element={<ProtectedRoute><TradingScreen /></ProtectedRoute>} />
          <Route path="/history" element={<ProtectedRoute><HistoryScreen /></ProtectedRoute>} />
          
          {/* Admin Routes */}
          <Route path="/admin/*" element={<AdminRoute><AdminScreen /></AdminRoute>} />
          
          {/* If a user tries any other path, redirect them. */}
          <Route path="*" element={<Navigate to={isLoggedIn ? "/" : "/profile"} replace />} />
        </Routes>
      </main>
      {isLoggedIn && !isAdminPage && <BottomNav />}
    </div>
  );
};

export default App;